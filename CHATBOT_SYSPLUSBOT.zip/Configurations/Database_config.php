<?php
	session_start();

	$option = 0;

	if($option == 0){
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "sysplusbot_database";
	}else{
		$servername = "";
		$username = "";
		$password = "";
		$dbname = "";
	}


	$conn = new mysqli($servername, $username, $password, $dbname);
	$dbconnect = mysqli_connect($servername, $username, $password, $dbname);

	if ($conn->connect_error) 
	{
	    die("Connection failed: " . $conn->connect_error);
	}

	date_default_timezone_set('Asia/Manila');

?>

