<!DOCTYPE html>
<html>
<head>
    <title>Admin SYSPLUSBOT</title>
    <style>
        /* Centering the view box */
        .container {
            width: 65%;
            height 10%;
            margin: 0 auto;
            text-align: center;
        }
           /* Style for the input box */
           #insert-form {
            margin-top: 20px;
        }
        /* Style for the table */
        table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }
        
        th {


        }
        
        td{
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            /* word-wrap: break-word; */
            height: auto;
            white-space: pre-wrap;
        }

        /* Making the table scrollable */
        .table-container {
            
            max-height: 350px; /* Adjust the height as needed */
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>SYSPLUSBOT</h2>
        
        <?php

        include('Configurations/Database_config.php');

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Create record
        if(isset($_POST['submit'])) {
            $name = $_POST['name'];

            $sql = "INSERT INTO items (name) VALUES ('$name')";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }

        // Read records
        $sql = "SELECT * FROM chatbot_datasets";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<div class='table-container'>";
            echo "<table border='1'>";
            echo "<tr><th>ID</th><th>Infomation</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>".$row["id"]."</td><td>".$row["information"]."</td></tr>";
            }
            echo "</table>";
            echo "</div>";
        } else {
            echo "0 results";
        }


        $conn->close();
        ?>
    </div>


    <!-- Form for adding new record -->
    <div class="container">
        <form id="insert-form" method="post" action="">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name">
            <input type="submit" name="submit" value="Add">
        </form>
    </div>
</body>
</html>
