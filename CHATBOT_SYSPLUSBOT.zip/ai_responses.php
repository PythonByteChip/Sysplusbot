<?php
include('Configurations/Database_config.php');
$raw_question = $_POST['text']; 

if(isset($_SESSION['trainer_mode']) && $_SESSION['trainer_mode'] == 0)
{
    if($raw_question != '/starttrainerengine passspcftraindata123') //to start trainer mode add the command and the password
    {
        $additionaldatasetinformation = " ";
        $sql = "SELECT * FROM chatbot_datasets;";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $additionaldatasetinformation .= $row['information'].' ,';
            }
        }



        //Prompt Engineering - instructions
        $AdditionalInfo1 = 'Please save the following information since it can be used in the following request questions of the user. '.$additionaldatasetinformation.' please save all of the informations.';
        $limitation = ' Please follow these guidelines: [prompt only relevant about SPCF and do not prompt if it is not relevant and say that it is off limit]';
        $tuitionfee = ' If the keyword "tuition fee" is detected only prompt specify the course and year level if user can not provide ask how may help you! ';
        $course = 'If the abbreviated course detected ask how may help with that course? else skip';


        // Count the total characters
        $totalCharacters = strlen($AdditionalInfo1);
        $totalWords = str_word_count($AdditionalInfo1);
        // Print the total characters in the console.log
        echo "<script>console.log('Total characters: $totalCharacters');</script>";
        echo "<script>console.log('Total words: $totalWords');</script>";
        echo "<script>console.log('Data Set: $AdditionalInfo1');</script>";


        // Users Query
        $user_query = $_POST['text'];


        // Set your OpenAI API key
        // $apiKey = 'sk-proj-Bpu1Wb96xNvbUwjhnmTrT3BlbkFJ91zEfe0nbMGat04y1GkR'; // Replace with your OpenAI API key
       $apiKey = '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'; //If Not working Try to resolve API key and model type
        // Set up the data for the request
        $data = [
            "model" => "gpt-4-turbo",//gpt-3.5-turbo
            'messages' => [
                ['role' => 'system', 'content' => $AdditionalInfo1 . $limitation . $tuitionfee . $course], 
                ['role' => 'system', 'content' => $user_query], 
            
                // ['role' => 'system', 'content' => $AdditionalInfo1], // First message for additional information
                // ['role' => 'system', 'content' => $_POST['text']], // Second message for the user's input
            ],
            'temperature' => 0.5,
            "max_tokens" => 1000,
            "top_p" => 1.0,
            "frequency_penalty" => 0.52,
            "presence_penalty" => 0.5,
            "stop" => ["11."],
        ];

        // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, 'https://api.openai.com/v1/chat/completions');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $apiKey,
            'Content-Type: application/json',
        ]);

        // Execute the cURL request
        $response = curl_exec($ch);

        // Check for errors
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        } else {
            // Parse the JSON response
            $json_response = json_decode($response, true);

            // Extract and return the generated text from the response
            if (isset($json_response['choices'][0]['message']['content']) && !empty($json_response['choices'][0]['message']['content'])) {
                $generated_text = $json_response['choices'][0]['message']['content']; // Extracting the response for the additional information
                echo nl2br($generated_text);
            } else {
                // Handle case where OpenAI does not provide a suitable response
                echo "I'm sorry, I couldn't find an answer to your question.";
            }
        }
        curl_close($ch);
    }
    else
    {
        $_SESSION['trainer_mode'] = 1; //trainer mode
        echo "Trainer Mode Engine Started, you can now add new datasets / information to the chatbot.";
    }
}
else
{
    if($raw_question != '/stoptrainerengine')
    {
        $query = "INSERT INTO chatbot_datasets (information) VALUES ('$raw_question')";
        $result = mysqli_query($dbconnect, $query);

        if($result) {
            // Data inserted successfully
            echo "Data has been trained successfully! type /stoptrainerengine to stop adding new dataset to the chatbot";
            // You can redirect the user or perform any other actions here
        } else {
            // Failed to insert data
            echo "Failed to process the data! please try again or type /stoptrainerengine to stop adding new dataset to the chatbot";
        }
    }
    else{

        $_SESSION['trainer_mode'] = 0; //trainer mode
        echo "Trainer Mode Engine Stopped, you can now ask questions to chatbot.";
    }
}

?>
