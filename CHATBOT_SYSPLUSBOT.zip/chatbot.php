

<style>
	@media (max-width: 768px) {
		.chatboticon{
			bottom:10vh !important;
		}
	}
	.voicebutton {
		margin-top: 1vh;
		float: left;
		background-color: white;
		border: 1px solid gray;
		color: black;
		height: 4.2vh;
		transition: background-color 0.3s; /* Smooth transition */
		border-radius: 0 2vh 2vh 0; /* Set radius only on the right */
		display: flex; /* Use flexbox */
		justify-content: center; /* Center horizontally */
		padding-top:1vh;
		align-items: center; /* Center vertically */    
		font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	}
	.voicebutton:hover {
		background-color: orange;
		color: black; /* Change text color to white on hover */
	}
	.chatboticon{
		width:4vh; height:4vh;
	}
</style>

<?php
	 $thisname = $_POST['username'];

	$input = "Hello ".$thisname."! How may I assist you today?";
	 
		if ($thisname === null || $thisname ==="") {
			// If $name is null, set it to "student"
			$input = "How may I assist you today?";
		}
		
?>

<link rel="stylesheet" href="chatbotDesign.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<div class="wrapper">
		<div class="title">
			<button class="voicebutton" type="button" id="voicebutton" onclick="startSpeechRecognition()"><i style="margin-top:-1vh;" class="fa fa-microphone"> <span style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-weight:normal;">Voice</span> </i> </button> 
		SYSPLUSBOT
		</div>
		<div class="form">
			<div class="bot-inbox inbox">
				<div class="icon">
					
						<img src="images/SYSPLUSBOT.gif" alt="SYSPLUSBOT GIF" class="chatboticon"/>
				</div>
				<div class="msg-header">
					<p>
					SysPlusBot is an innovative chatbot designed to be your one-stop source for information about Systems Plus Colloge Foundation. SysPlusBot can provide you information on a wide range of topics, including:
					<br><br>Academics (programs & courses)
					<br>Tuition Fee, Curriculum
					<br>Department location, facilities
					<br>Department deans & faculty members
					<br>School history, spcf hymn, mission & vision
					<br>Enrollment process, requirements, Scholarship requirements
					<br>Contact Information
					<br><br>Think of SysPlusBot as your friendly and efficient guide to navigating SPCF. 
					</p>
				</div>
			</div>
			<div class="bot-inbox inbox">
				<div class="icon">
					
						<img src="images/SYSPLUSBOT.gif" alt="SYSPLUSBOT GIF" class="chatboticon"/>
				</div>
				<div class="msg-header">
					<p style="text-transform: capitalize;">
						<?php echo $input;?>
					</p>
				</div>
			</div>
		</div>
		<div class="typing-field">
			<div class="input-data">
				<input id="data" type="text"  placeholder="Type something here.." maxlength="200" onkeypress="handleKeyPress(event)"
					required>
				<button id="send-btn" type="button">Send</button>
				<script>
					function startSpeechRecognition() {
					  const voiceButton = document.getElementById('voicebutton');
					  voiceButton.style.backgroundColor = 'lightgreen';
					  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition || window.mozSpeechRecognition || window.msSpeechRecognition)();
					  
					  recognition.lang = 'en-US';
					  recognition.interimResults = false;
					  recognition.maxAlternatives = 1;
					
					  // Speech synthesis for initial instruction
					//   const initialInstructions = [
					// 	"startspeaking",
					// 	"start",
					// 	"speak",
					// 	"listening"
					// ];

					// // Generate a random index to select a random instruction
					// const randomIndex = Math.floor(Math.random() * initialInstructions.length);

					// // Create the SpeechSynthesisUtterance with the randomly selected instruction
					// const initialInstruction = new SpeechSynthesisUtterance(initialInstructions[randomIndex]);
					  const initialInstruction = new SpeechSynthesisUtterance("speak");
					  speechSynthesis.speak(initialInstruction);
					
					  recognition.onresult = (event) => {
					    const speechResult = event.results[0][0].transcript.trim(); // Trim to remove trailing spaces and periods
					    document.getElementById('data').value = speechResult;
					
					  };
					
					  recognition.onerror = (event) => {
					    console.error('Speech recognition error:', event.error);
					    voiceButton.style.backgroundColor = ''; 
					  };
					
					  recognition.onend = () => {
					    console.log('Speech recognition ended.');
					    voiceButton.style.backgroundColor = ''; 
					  };
					
					  // Start speech recognition
					  recognition.start();
					}
				</script>
			</div>
		</div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
	$(document).ready(function () {
	    $("#send-btn").on("click", function () {
	        sendMessage();
	    });
	});
	
	function handleKeyPress(event) {
	    if (event.keyCode === 13) {
	        event.preventDefault();
	        sendMessage();
	    }
	}
	
	function sendMessage() {
	    var value = $("#data").val().trim();
	
	    if (value === "") {
	        return; // Exit the function if the input field is empty
	    }
	
	    var message = '<div class="user-inbox inbox"><div class="msg-header"><p>' + value + '</p></div></div>';
	    $(".form").append(message);
	    $("#data").val("");
	
	$.ajax({ 
	  url: "ai_responses.php", // Send the message to your PHP script
	  type: "POST",
	  data: { text: value }, // Pass the user's message as 'text' parameter
	  success: function (result) {
	      // Display the response from OpenAI
	      var reply = '<div class="bot-inbox inbox"><div class="icon"><img src="images/SYSPLUSBOT.gif" alt="SYSPLUSBOT GIF" class="chatboticon"/></div><div class="msg-header"><p>' + result + '</p></div></div>';
	      $(".form").append(reply);
	      $(".form").scrollTop($(".form")[0].scrollHeight);
	  },
	});
	
	}
	
	$("#data").on("input", function () {
	    var inputVal = $(this).val().trim();
	    var sendBtn = $("#send-btn");
	
	    if (inputVal === "") {
	        sendBtn.prop("disabled", true);
	    } else {
	        sendBtn.prop("disabled", false);
	    }
	});
	

	console.log(userName);
</script>